using System;
using System.Diagnostics;
using System.IO;
using System.Text;

// ============================================================================
//  softlight.exe — cau noi giua dslrBooth va bo xu ly Node.
//
//  Vi sao can .exe chu khong dung .bat:
//
//   1) O muc Post-Processing, dslrBooth mo hop thoai chon Application va cho
//      chon file thuc thi.
//   2) File .bat chay qua cmd.exe, ma cmd PHAN TICH LAI dong lenh. Tham so
//      chua ky tu | (danh sach file cua dslrBooth) se bi hieu thanh toan tu
//      pipe va lam vo lenh — loi xay ra TRUOC khi .bat chay nen khong sua
//      duoc tu ben trong. Tien trinh nay nhan argv truc tiep, khong qua shell.
//   3) /target:winexe nen khong co cua so console nhay len moi lan chup.
//
//  Bien dich: build-exe.bat
// ============================================================================

static class Launcher
{
    // Chan tren de mot lan xu ly treo khong lam dslrBooth dung hinh mai.
    const int TimeoutMs = 60000;

    static int Main(string[] args)
    {
        string dir = AppDomain.CurrentDomain.BaseDirectory;
        string script = Path.Combine(dir, "src\\cli.js");
        string node = ResolveNode(dir);

        var sb = new StringBuilder();
        sb.Append(Quote(script));
        foreach (string a in args) { sb.Append(' '); sb.Append(Quote(a)); }

        try
        {
            var psi = new ProcessStartInfo(node, sb.ToString())
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WorkingDirectory = dir,
            };
            using (Process p = Process.Start(psi))
            {
                if (!p.WaitForExit(TimeoutMs))
                {
                    try { p.Kill(); } catch { }
                    Log(dir, "timeout sau " + TimeoutMs + "ms");
                }
            }
        }
        catch (Exception ex)
        {
            Log(dir, "khong chay duoc node (" + node + "): " + ex.Message);
        }

        // Luon tra 0. Mot su co hau ky khong duoc phep lam gian doan phien chup
        // cua khach, va dslrBooth van con anh goc de dung tiep.
        return 0;
    }

    /// Uu tien node-path.txt dat canh file exe; neu khong co thi de Windows tu
    /// tim node.exe trong PATH.
    static string ResolveNode(string dir)
    {
        string cfg = Path.Combine(dir, "node-path.txt");
        if (File.Exists(cfg))
        {
            string s = File.ReadAllText(cfg).Trim();
            if (s.Length > 0) return s;
        }
        return "node.exe";
    }

    static void Log(string dir, string msg)
    {
        try
        {
            string logDir = Path.Combine(dir, "logs");
            Directory.CreateDirectory(logDir);
            File.AppendAllText(
                Path.Combine(logDir, "softlight.log"),
                "{\"t\":\"" + DateTime.UtcNow.ToString("o") + "\",\"ev\":\"launcher\",\"error\":\""
                    + msg.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"}\n");
        }
        catch { }
    }

    /// Dat dau nhay cho mot tham so theo dung quy tac cua Windows CommandLineToArgvW.
    /// Phai tu lam vi .NET Framework 4 chua co ProcessStartInfo.ArgumentList.
    static string Quote(string s)
    {
        if (s.Length > 0 && s.IndexOfAny(new[] { ' ', '\t', '\n', '\v', '"' }) < 0) return s;

        var sb = new StringBuilder("\"");
        for (int i = 0; i < s.Length; i++)
        {
            int slashes = 0;
            while (i < s.Length && s[i] == '\\') { slashes++; i++; }

            if (i == s.Length) { sb.Append('\\', slashes * 2); break; }
            if (s[i] == '"') { sb.Append('\\', slashes * 2 + 1).Append('"'); }
            else { sb.Append('\\', slashes).Append(s[i]); }
        }
        sb.Append('"');
        return sb.ToString();
    }
}
