import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const CONFIG_PATH = join(ROOT, 'softlight.config.json');

/** Giá trị mặc định — file cấu hình chỉ cần ghi đè phần muốn đổi. */
const DEFAULTS = {
  enabled: true,
  softFocus: { amount: 0.22, radiusPct: 0.16 },
  clarity: { amount: 0.28, radiusPct: 2.0 },
  glow: { amount: 0.3, radiusPct: 1.6, threshold: 0.6 },
  tone: { contrast: -0.12, lift: 0.022 },
  warm: { temp: 0.07, tint: 0.012, highlightWarmth: 0.06, highlightColor: '#ffd9a8' },
  output: { quality: 95, chromaSubsampling: '4:4:4' },
  backup: { enabled: true, folder: '_original' },
  skip: { pathContains: [] },
  limits: { minEdge: 400, maxMs: 1500 },
};

const num = (v, lo, hi, dflt) => {
  const n = typeof v === 'number' && Number.isFinite(v) ? v : dflt;
  return Math.min(hi, Math.max(lo, n));
};

/**
 * Đọc và kẹp cấu hình về miền an toàn. Cấu hình do người vận hành sửa tay giữa
 * các sự kiện nên mọi giá trị đều phải chịu được số nhập sai mà không làm hỏng
 * ảnh của khách — kẹp im lặng, không ném lỗi.
 */
export function loadConfig(path = CONFIG_PATH) {
  let raw = {};
  try {
    raw = JSON.parse(readFileSync(path, 'utf8'));
  } catch (err) {
    if (err.code !== 'ENOENT') {
      throw new Error(`Cấu hình hỏng (${path}): ${err.message}`);
    }
  }

  const d = DEFAULTS;
  const sf = { ...d.softFocus, ...raw.softFocus };
  const c = { ...d.clarity, ...raw.clarity };
  const g = { ...d.glow, ...raw.glow };
  const t = { ...d.tone, ...raw.tone };
  const w = { ...d.warm, ...raw.warm };
  const o = { ...d.output, ...raw.output };
  const b = { ...d.backup, ...raw.backup };
  const sk = { ...d.skip, ...raw.skip };
  const l = { ...d.limits, ...raw.limits };

  return {
    enabled: raw.enabled !== false,
    softFocus: {
      amount: num(sf.amount, 0, 0.9, d.softFocus.amount),
      radiusPct: num(sf.radiusPct, 0.02, 3, d.softFocus.radiusPct),
    },
    clarity: {
      amount: num(c.amount, 0, 0.9, d.clarity.amount),
      radiusPct: num(c.radiusPct, 0.1, 10, d.clarity.radiusPct),
    },
    glow: {
      amount: num(g.amount, 0, 1, d.glow.amount),
      radiusPct: num(g.radiusPct, 0.1, 10, d.glow.radiusPct),
      threshold: num(g.threshold, 0, 0.95, d.glow.threshold),
    },
    tone: {
      contrast: num(t.contrast, -0.6, 0.6, d.tone.contrast),
      lift: num(t.lift, 0, 0.2, d.tone.lift),
    },
    warm: {
      temp: num(w.temp, -0.4, 0.4, d.warm.temp),
      tint: num(w.tint, -0.4, 0.4, d.warm.tint),
      highlightWarmth: num(w.highlightWarmth, 0, 0.5, d.warm.highlightWarmth),
      highlightColor: /^#[0-9a-fA-F]{6}$/.test(w.highlightColor)
        ? w.highlightColor
        : d.warm.highlightColor,
    },
    output: {
      quality: Math.round(num(o.quality, 60, 100, d.output.quality)),
      chromaSubsampling: o.chromaSubsampling === '4:2:0' ? '4:2:0' : '4:4:4',
    },
    backup: {
      enabled: b.enabled !== false,
      folder: typeof b.folder === 'string' && b.folder.trim() ? b.folder.trim() : d.backup.folder,
    },
    skip: {
      pathContains: Array.isArray(sk.pathContains)
        ? sk.pathContains.filter((x) => typeof x === 'string' && x.trim()).map((x) => x.trim())
        : [],
    },
    limits: {
      minEdge: Math.round(num(l.minEdge, 0, 20000, d.limits.minEdge)),
      maxMs: Math.round(num(l.maxMs, 100, 60000, d.limits.maxMs)),
    },
  };
}

export function hexToRgb(hex) {
  return {
    r: parseInt(hex.slice(1, 3), 16),
    g: parseInt(hex.slice(3, 5), 16),
    b: parseInt(hex.slice(5, 7), 16),
  };
}
